using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public static GameController gc;
    public Text coinsText;
    public int coins;
    public Text lifetext;
    public int lives = 3;

    void Awake()
    {
        if(gc == null)
        {
            gc = this;
            DontDestroyOnLoad(gameObject);
        }
        else if(gc != this)
        {
            Destroy(gameObject);
        }
        RefreshScreen();
    }

    public void SetLives(int life)
    {
        lives += life;
        if(lives >= 0)
        RefreshScreen();
    }

    public void SetCoins(int coin)
    {
        coins += coin;
        if(coins >= 20)
        {
            coins = 0;
            lives += 1;
        }
        RefreshScreen() ;
    }

    public void RefreshScreen()
    {
        coinsText.text = coins.ToString();
        lifetext.text = lives.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

using UnityEngine;

public class Player : MonoBehaviour
{
    private Animator playerAnim;
    private Rigidbody2D rbPlayer;
    public float speed;
    public float jumpForce;
    private SpriteRenderer sr;
    public bool inFloor = true;
    public bool doubleJump;
    public bool tripleJump;
    private GameController gcPlayer;
    public int coins;

    public AudioSource audioS;
    public AudioClip[] Sounds;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        gcPlayer = GameController.gc;
        gcPlayer.coins = 0;
        playerAnim = GetComponent<Animator>();
        rbPlayer = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    private void FixedUpdate()
    {
        MovePlayer();
    }
    void Update()
    {
        Jump();
    }

    void MovePlayer()
    {
        float horizontalMoviment = Input.GetAxis("Horizontal");
        //Debug.log(horizontalMoviment);
        rbPlayer.linearVelocity = new Vector2(horizontalMoviment * speed, rbPlayer.linearVelocity.y);

        if (horizontalMoviment > 0)
        {
            playerAnim.SetBool("Walk", true);
            sr.flipX = false;
        }
        else if (horizontalMoviment < 0)
        {
            playerAnim.SetBool("Walk", true);
            sr.flipX = true;
        }
        else
        {
            playerAnim.SetBool("Walk", false);
        }
    }

    void Jump()
    {
        if (Input.GetButton("Jump"))
        {
            if (inFloor)
            {
                audioS.clip = Sounds[1];
                audioS.Play();
                rbPlayer.linearVelocity = Vector2.zero;
                playerAnim.SetBool("Jump", true);
                rbPlayer.AddForce(new Vector2(0, jumpForce), ForceMode2D.Impulse);
                inFloor = false;
                doubleJump = true;
            }
            else if (!inFloor && doubleJump)
            {
                audioS.clip = Sounds[1];
                audioS.Play();
                rbPlayer.linearVelocity = Vector2.zero;
                playerAnim.SetBool("Jump", true);
                rbPlayer.AddForce(new Vector2(0, jumpForce), ForceMode2D.Impulse);
                inFloor = false;
                doubleJump = false;
                tripleJump = true;
            }
            else if (!inFloor && doubleJump)
            {
                audioS.clip = Sounds[1];
                audioS.Play();
                rbPlayer.linearVelocity = Vector2.zero;
                playerAnim.SetBool("Jump", true);
                rbPlayer.AddForce(new Vector2(0, jumpForce), ForceMode2D.Impulse);
                inFloor = false;
                doubleJump = false;
                tripleJump = false;
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Ground")
        {
            playerAnim.SetBool("Jump", false);
            inFloor = true;
            doubleJump = false;
            tripleJump = false;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Coins")
        {
            audioS.clip = Sounds[0];
            audioS.Play();
            Destroy(collision.gameObject);
            //gcPlayer.coins++;
            gcPlayer.SetCoins(1);
            GameController.gc.RefreshScreen();
        }

        if (collision.gameObject.tag == "Enemy")
        {
            audioS.clip = Sounds[2];
            audioS.Play();
            rbPlayer.linearVelocity = Vector2.zero;
            rbPlayer.AddForce(Vector2.up * 5, ForceMode2D.Impulse);
            collision.gameObject.GetComponent<SpriteRenderer>().flipY = true;
            collision.gameObject.GetComponent<Enemy>().enabled = false;
            collision.gameObject.GetComponent<CapsuleCollider2D>().enabled = false;
            collision.gameObject.GetComponent<BoxCollider2D>().enabled = false;
            collision.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Kinematic;
            Destroy(collision.gameObject, 1f);
    }   }

}